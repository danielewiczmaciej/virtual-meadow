#pragma once
#include "Animal.h"
#include "Antylope.h"
#include "Borscht.h"
#include "Dandelion.h"
#include "Fox.h"
#include "Ground.h"
#include "Guarana.h"
#include "Human.h"
#include "Org.h"
#include "Plant.h"
#include "Sheep.h"
#include "Turtle.h"
#include "Wolf.h"
#include "Wolfberries.h"
#include "World.h"

class World;